//
//  AppDelegate.h
//  Advanced-Example
//

#import <UIKit/UIKit.h>

@class KSCrashInstallation;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow* window;
@property (strong, nonatomic) KSCrashInstallation* crashInstallation;

@end
