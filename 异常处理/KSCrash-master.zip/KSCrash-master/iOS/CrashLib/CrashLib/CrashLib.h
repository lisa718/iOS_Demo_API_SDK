//
//  CrashLib.h
//  CrashLib
//
//  Created by Karl Stenerud on 2017-01-25.
//  Copyright © 2017 Karl Stenerud. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CrashLib.
FOUNDATION_EXPORT double CrashLibVersionNumber;

//! Project version string for CrashLib.
FOUNDATION_EXPORT const unsigned char CrashLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CrashLib/PublicHeader.h>


