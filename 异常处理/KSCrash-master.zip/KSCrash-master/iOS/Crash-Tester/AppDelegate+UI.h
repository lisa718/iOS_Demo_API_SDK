//
//  AppDelegate+UI.h
//
//  Created by Karl Stenerud on 2012-03-04.
//

#import "AppDelegate.h"

@interface AppDelegate (UI)

- (UIViewController*) createRootViewController;

@end
