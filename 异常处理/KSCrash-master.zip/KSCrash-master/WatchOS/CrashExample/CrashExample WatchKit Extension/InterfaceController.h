//
//  InterfaceController.h
//  CrashExample WatchKit Extension
//
//  Created by Karl on 2016-10-18.
//  Copyright © 2016 Karl Stenerud. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface InterfaceController : WKInterfaceController

@end
