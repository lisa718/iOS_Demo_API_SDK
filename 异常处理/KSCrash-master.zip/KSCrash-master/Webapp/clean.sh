#!/bin/sh

rm -rf posts
rm *.pyc
