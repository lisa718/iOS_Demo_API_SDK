//
//  AppDelegate.h
//  SimpleExample
//
//  Created by karl on 2016-04-08.
//  Copyright © 2016 Karl Stenerud. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

