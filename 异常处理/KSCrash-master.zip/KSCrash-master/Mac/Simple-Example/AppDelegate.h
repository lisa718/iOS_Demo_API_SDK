//
//  AppDelegate.h
//  Simple-Example
//
//  Created by Karl Stenerud on 9/19/13.
//  Copyright (c) 2013 Karl Stenerud. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
