//
//  main.m
//  Simple-Example
//
//  Created by Karl Stenerud on 9/19/13.
//  Copyright (c) 2013 Karl Stenerud. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[])
{
    return NSApplicationMain(argc, argv);
}
